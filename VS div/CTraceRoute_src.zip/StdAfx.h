#define VC_EXTRALEAN		

#include <afxwin.h>     
#include <afxext.h>     
#include <winsock.h>
#include <afxtempl.h>
#include <afxpriv.h>
